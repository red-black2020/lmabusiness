<?php
/**
 * Your Twitter App Info
 */

// Consumer Key
define('CONSUMER_KEY', 'eUvGfYgmTeYcwrvWKMFkIqG8D');
define('CONSUMER_SECRET', 'ltVAvkTLyTXOQUByWr6PZw8NSbs1GTozq1O5SAy0rnecKDkLRN');

// User Access Token
define('ACCESS_TOKEN', '400702350-UjInWJdo5iBdQpX0C5fLt4wtI3RhDBUrBToxCMBg');
define('ACCESS_SECRET', '82K2n8CKly7zxXGndY970UcDnCuJ5HNUhlxI9fvSdVybz');

// Cache Settings
define('CACHE_ENABLED', false);
define('CACHE_LIFETIME', 3600); // in seconds
define('HASH_SALT', md5(dirname(__FILE__)));