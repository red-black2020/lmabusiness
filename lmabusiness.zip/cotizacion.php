<!DOCTYPE html>
<!--META-START -->
<?php include 'metadata.php';?>
<!--HEADER-END -->
<body>
    <!--PAGE-LOADER-START -->
    <?php include 'page-loader.php';?>
    <!--PAGE-LOADER-END -->
    <div class="page text-center text-md-left">
        <!--HEADER-START -->
        <?php include 'header.php';?>
        <!--HEADER-END -->


        <!--COTIZACION-START-->
        <!--COTIZACION-END-->



        <!--FOOTER-START -->
        <?php include 'footer.php';?>
        <!--FOOTER-END -->
        </div>
        <div class="snackbars" id="form-output-global"></div>
    </div>
    <!--SCRIPTS-START -->
    <?php include 'scripts.php';?>
    <!--SCRIPTS-END -->
  </body>
</html>